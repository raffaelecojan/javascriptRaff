//Gestione data colloquiato
document.getElementById('inputDataCol').addEventListener('input', function(e) {
    var value = e.target.value.replace(/\D/g, ''); // Rimuove tutto tranne i numeri
    if (value.length > 2) {
        value = value.substring(0, 2) + '/' + value.substring(2);
    }
    if (value.length > 5) {
        value = value.substring(0, 5) + '/' + value.substring(5);
    }
    e.target.value = value;
});






// Funzione per svuotare i campi del form
function reset() {
    document.getElementById('inputNome').value = '';
    document.getElementById('inputCognome').value = '';
    document.getElementById('inputDataCol').value = '';
    document.getElementById('inputCitta').value = '';
    document.getElementById('inputColDa').value = '';
    document.getElementById('inputAmbito').value = '';
    document.getElementById('inputEsito').value = '';
    document.getElementById('inputProvenienza').value = '';
    document.getElementById('inputNote').value = '';

    // Chiudi il pop-up se è aperto
    closePopup();
}

// Funzione per validare il form
function validateForm() {
    const form = document.getElementById('myForm');
    let valid = true;
    const elements = form.elements;

    for (let i = 0; i < elements.length; i++) {
        elements[i].classList.remove('is-invalid');
    }

    for (let i = 0; i < elements.length; i++) {
        if (!elements[i].checkValidity()) {
            elements[i].classList.add('is-invalid');
            valid = false;
        }
    }
    return valid;
}

// Funzione per gestire il pop-up di recap dei dati
function updatePopupContent() {
    document.getElementById("popupNome").textContent = document.getElementById("inputNome").value;
    document.getElementById("popupCog").textContent = document.getElementById("inputCognome").value;
    document.getElementById("popupDataCol").textContent = document.getElementById("inputDataCol").value;
    document.getElementById("popupCitta").textContent = document.getElementById("inputCitta").value;
    document.getElementById("popupColDa").textContent = document.getElementById("inputColDa").value;
    document.getElementById("popupAmbito").textContent = document.getElementById("inputAmbito").value;
    document.getElementById("popupEsito").textContent = document.getElementById("inputEsito").value;
    document.getElementById("popupProv").textContent = document.getElementById("inputProvenienza").value;
    document.getElementById("popupNote").textContent = document.getElementById("inputNote").value;
}

// Funzione per mostrare il pop-up
function showPopup() {
    updatePopupContent(); // Aggiorna il contenuto del pop-up con i dati attuali del form

    var modal = document.getElementById("popupModal");
    modal.style.display = "block";
}

// Funzione per chiudere il pop-up
function closePopup() {
    var modal = document.getElementById("popupModal");
    modal.style.display = "none";
}


// Funzione per il pulsante Invia
function sendData() {
    var modal = new bootstrap.Modal(document.getElementById('exampleModal'));
    modal.show();
}

// Funzione per aprire il secondo pop-up per inserire destinatario e oggetto
function openSecondPopup() {
    document.getElementById('exampleModal').style.display = 'block';
}

// Event listener per il pulsante Salva
document.getElementById("saveButton").addEventListener("click", function() {
    if (validateForm()) {
        showPopup(); // Mostra il pop-up con il recap dei dati
    } else {
        alert('Campo mancante');
    }
});

// Event listener per il pulsante Reset
document.querySelector('button[type="reset"]').addEventListener("click", reset);



// Chiudi il pop-up quando si clicca fuori dal contenuto del pop-up
window.addEventListener("click", function(event) {
    var modal = document.getElementById("popupModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
});

function showInputField(selectElement) {
    var selectedValue = selectElement.value;
    var altroInputDiv = document.getElementById('altroInput');

    if (selectedValue === 'Altro') {
        altroInputDiv.style.display = 'block';
    } else {
        altroInputDiv.style.display = 'none';
    }
}

document.getElementById('inputDataCol').addEventListener('keypress', function (e) {
    const char = String.fromCharCode(e.which);
    if (!/[0-9\/]/.test(char)) {
        e.preventDefault();
    }
});

document.getElementById('inputDataCol').addEventListener('paste', function (e) {
    const pastedData = (e.clipboardData || window.clipboardData).getData('text');
    if (/[^0-9\/]/.test(pastedData)) {
        e.preventDefault();
    }
});

// Chiudi il pop-up quando si clicca sulla 'x'
function closePopup1() {
    var modal2 = document.getElementById("exampleModal");
    modal2.classList.remove('show');
    
    setTimeout(() => {
        modal2.classList.remove('fade');
        modal2.style.display = "none";
    }, 1); // corrisponde al tempo della transizione del fade

    document.body.classList.remove('modal-open');
    
    var backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) {
        backdrop.remove();
    }
}

function closePopup2() {
    var modal3 = document.getElementById("popupModal");
    modal3.style.display = "none";
}